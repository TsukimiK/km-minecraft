KM Minecraft - Production permissions notes

Public /trigger acquisition has been disabled.
Normal players can use gameplay features (plant, harvest, bone meal, eat, smoke/open box) but cannot run /function commands without sufficient command permission.

OP/admin seed commands:
/function km-minecraft:farming/give_seeds
/function km-minecraft:farming/debug/give_rare_seeds

OP/admin debug command:
/function km-minecraft:farming/debug/grow_nearby

Seeds are not automatically granted to normal players. Hand them out from OP/admin as intended.
