KM Minecraft 26.2 update

- Vegeter naming: Vegeter （BOX） / Vegeter
- Vegeter BOX recipe: paper x6 + daikon x3 (top/bottom paper, middle daikon)
- Vegeter: nutrition 2, saturation 8.0, poison 2 seconds
- Crop interaction hitbox enlarged to width 1.20 / height 1.35
- Natural crop growth slowed to avg. ~5 min per stage (~10 min total avg.)
- Daikon food = potato (nutrition 1, saturation 0.6)
- Cooked daikon = baked potato (nutrition 5, saturation 6.0)
- Cooked Asahatamon = golden apple food values only (nutrition 4, saturation 9.6; no golden-apple effects)
- Recipes unlock when daikon / Asahatamon is first acquired
- Third-person flat item display transforms changed to vanilla generated-item style
