# Event position = block hit by the enchanted tool.
execute if block ~ ~ ~ minecraft:bedrock run setblock ~ ~ ~ minecraft:air destroy
