# The bedrock-breaker enchantment exists only while sneaking.
# Vanilla enchantments already on the tool are preserved.
execute if predicate km-minecraft:asahatamon/is_sneaking run item modify entity @s weapon.mainhand km-minecraft:asahatamon/add_bedrock_breaker
execute unless predicate km-minecraft:asahatamon/is_sneaking run item modify entity @s weapon.mainhand km-minecraft:asahatamon/remove_bedrock_breaker
