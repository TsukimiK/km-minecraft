give @s minecraft:diamond_sword[minecraft:custom_name={text:"あさはたもんの剣",color:"green",italic:false},minecraft:custom_data={km_minecraft:{asahatamon_tool:"sword"}},minecraft:item_model="km-minecraft:asahatamon/upgraded_sword"] 1
give @s minecraft:diamond_pickaxe[minecraft:custom_name={text:"あさはたもんのツルハシ",color:"green",italic:false},minecraft:custom_data={km_minecraft:{asahatamon_tool:"pickaxe"}},minecraft:item_model="km-minecraft:asahatamon/upgraded_pickaxe"] 1
give @s minecraft:diamond_axe[minecraft:custom_name={text:"あさはたもんの斧",color:"green",italic:false},minecraft:custom_data={km_minecraft:{asahatamon_tool:"axe"}},minecraft:item_model="km-minecraft:asahatamon/upgraded_axe"] 1
give @s minecraft:diamond_shovel[minecraft:custom_name={text:"あさはたもんのシャベル",color:"green",italic:false},minecraft:custom_data={km_minecraft:{asahatamon_tool:"shovel"}},minecraft:item_model="km-minecraft:asahatamon/upgraded_shovel"] 1
give @s minecraft:nether_star[minecraft:custom_name={text:"あさはたもんの結晶",color:"green",italic:false},minecraft:custom_data={km_minecraft:{asahatamon_crystal:true}},minecraft:item_model="km-minecraft:asahatamon/crystal"] 1
function km-minecraft:asahatamon/give_omnitool
