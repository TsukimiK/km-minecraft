tag @s add km_daikon_checked
summon minecraft:marker ~ ~ ~ {Tags:["km_daikon_slice_marker","km_daikon_slice_mount"]}
ride @e[type=minecraft:marker,tag=km_daikon_slice_mount,distance=..0.25,sort=nearest,limit=1] mount @s
tag @e[type=minecraft:marker,tag=km_daikon_slice_mount,distance=..0.25,sort=nearest,limit=1] remove km_daikon_slice_mount
