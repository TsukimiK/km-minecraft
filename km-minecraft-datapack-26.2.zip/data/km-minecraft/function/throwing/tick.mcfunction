execute as @e[type=minecraft:snowball,tag=!km_daikon_checked,nbt={Item:{components:{"minecraft:custom_data":{km_minecraft:{item:"daikon_slice"}}}}}] at @s run function km-minecraft:throwing/init_slice
execute as @e[type=minecraft:marker,tag=km_daikon_slice_marker] unless predicate km-minecraft:throwing/has_vehicle at @s run function km-minecraft:throwing/impact
tag @e[type=minecraft:snowball,tag=!km_daikon_checked] add km_daikon_checked
