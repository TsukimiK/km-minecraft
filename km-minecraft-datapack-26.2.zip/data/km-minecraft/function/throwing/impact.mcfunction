tag @s add km_daikon_impact_current
execute positioned ~ ~-0.65 ~ as @e[distance=..1.15,sort=nearest,tag=!km_daikon_impact_current] if data entity @s Health run function km-minecraft:throwing/hit_target
kill @s
