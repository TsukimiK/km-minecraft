execute if entity @e[type=minecraft:marker,tag=km_daikon_impact_current,distance=..1.8,limit=1] run damage @s 1 minecraft:thrown
kill @e[type=minecraft:marker,tag=km_daikon_impact_current,distance=..1.8,limit=1]
