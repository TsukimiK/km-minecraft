item replace entity @s weapon.mainhand with minecraft:air
playsound minecraft:entity.item.break player @s ~ ~ ~ 1.0 1.0
kill @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1]
