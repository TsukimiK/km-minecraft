
scoreboard players add #clock kmtool_clock 1
execute as @a at @s run function km-minecraft:tools/player_tick
execute as @e[type=minecraft:armor_stand,tag=kmtool_backup] run function km-minecraft:tools/cleanup_backup
