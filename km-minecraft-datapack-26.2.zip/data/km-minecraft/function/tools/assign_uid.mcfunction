scoreboard players add #next kmtool_uid 1
scoreboard players operation @s kmtool_uid = #next kmtool_uid
