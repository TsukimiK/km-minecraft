advancement revoke @s only km-minecraft:tools/consumed

tag @e[type=minecraft:armor_stand,tag=kmtool_backup] remove kmtool_selected
scoreboard players operation #target kmtool_uid = @s kmtool_uid
execute as @e[type=minecraft:armor_stand,tag=kmtool_backup] if score @s kmtool_uid = #target kmtool_uid run tag @s add kmtool_selected
execute if entity @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] if score @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] kmtool_damage matches ..194 run function km-minecraft:tools/restore_after_eat
execute if entity @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] if score @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] kmtool_damage matches 195 run function km-minecraft:tools/break_after_eat
execute if entity @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] if score @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] kmtool_damage matches 196.. run function km-minecraft:tools/emergency_restore
