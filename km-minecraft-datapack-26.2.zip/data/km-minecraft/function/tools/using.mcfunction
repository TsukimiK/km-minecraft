
advancement revoke @s only km-minecraft:tools/using
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:true}}] run title @s actionbar {"text":"耐久度が足りないため食べられません","color":"red"}
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:false}}] run function km-minecraft:tools/backup_mainhand
execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] if items entity @s weapon.offhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] run title @s actionbar {"text":"食べるときはメインハンドに持ってください","color":"yellow"}
