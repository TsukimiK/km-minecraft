# Safety fallback: should never complete because the disabled consumable takes 1 hour.
item replace entity @s weapon.mainhand from entity @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] weapon.mainhand
item modify entity @s weapon.mainhand km-minecraft:tools/disable_eating
title @s actionbar {"text":"耐久度が足りないため食べられません","color":"red"}
kill @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1]
