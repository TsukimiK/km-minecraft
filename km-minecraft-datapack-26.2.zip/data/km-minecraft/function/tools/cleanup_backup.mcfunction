scoreboard players operation #age kmtool_clock = #clock kmtool_clock
scoreboard players operation #age kmtool_clock -= @s kmtool_last
execute if score #age kmtool_clock matches 8.. run kill @s
