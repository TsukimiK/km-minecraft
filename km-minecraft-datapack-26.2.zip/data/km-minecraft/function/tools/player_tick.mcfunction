execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] unless items entity @s weapon.offhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] run return 0
execute unless score @s kmtool_uid matches 1.. run function km-minecraft:tools/assign_uid
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] run function km-minecraft:tools/check_mainhand
execute if items entity @s weapon.offhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:false}}] run item modify entity @s weapon.offhand km-minecraft:tools/disable_eating
