execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] unless items entity @s weapon.offhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] run return 0
# One-time visual fix for tools created before the third-person particle hotfix.
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:false}}] unless items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{thirdperson_fix:true}}] run item modify entity @s weapon.mainhand km-minecraft:tools/enable_eating
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:true}}] unless items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{thirdperson_fix:true}}] run item modify entity @s weapon.mainhand km-minecraft:tools/disable_eating

execute unless score @s kmtool_uid matches 1.. run function km-minecraft:tools/assign_uid
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true}}] run function km-minecraft:tools/check_mainhand
# Eating is intentionally main-hand only; off-hand is made non-consumable to prevent item loss.
execute if items entity @s weapon.offhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:false}}] run item modify entity @s weapon.offhand km-minecraft:tools/disable_eating
