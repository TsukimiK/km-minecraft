scoreboard players set @s kmtool_damage 0
execute store result score @s kmtool_damage run data get entity @s SelectedItem.components."minecraft:damage" 1
execute if score @s kmtool_damage matches 196.. if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:false}}] run item modify entity @s weapon.mainhand km-minecraft:tools/disable_eating
execute if score @s kmtool_damage matches ..195 if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{daikon_tool:true,eat_disabled:true}}] run item modify entity @s weapon.mainhand km-minecraft:tools/enable_eating
