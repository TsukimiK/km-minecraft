
scoreboard objectives add kmtool_uid dummy
scoreboard objectives add kmtool_clock dummy
scoreboard objectives add kmtool_damage dummy
scoreboard objectives add kmtool_last dummy
scoreboard players add #next kmtool_uid 0
scoreboard players add #clock kmtool_clock 0
kill @e[type=minecraft:armor_stand,tag=kmtool_backup]
