function km-minecraft:tools/give/daikon_sword
function km-minecraft:tools/give/daikon_pickaxe
function km-minecraft:tools/give/daikon_axe
function km-minecraft:tools/give/daikon_shovel
