scoreboard players set @s kmtool_damage 0
execute store result score @s kmtool_damage run data get entity @s SelectedItem.components."minecraft:damage" 1

# Find this player's temporary backup entity.
tag @e[type=minecraft:armor_stand,tag=kmtool_backup] remove kmtool_selected
scoreboard players operation #target kmtool_uid = @s kmtool_uid
execute as @e[type=minecraft:armor_stand,tag=kmtool_backup] if score @s kmtool_uid = #target kmtool_uid run tag @s add kmtool_selected

# Create it only once per eating action.
execute unless entity @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] run summon minecraft:armor_stand ~ ~-2 ~ {Tags:["kmtool_backup","kmtool_selected","kmtool_new"],Invisible:1b,Marker:1b,Small:1b,NoGravity:1b,Invulnerable:1b,Silent:1b}

# Link a new backup to this player and copy the full item only once.
execute as @e[type=minecraft:armor_stand,tag=kmtool_selected,tag=kmtool_new,limit=1] run scoreboard players operation @s kmtool_uid = #target kmtool_uid
item replace entity @e[type=minecraft:armor_stand,tag=kmtool_selected,tag=kmtool_new,limit=1] weapon.mainhand from entity @s weapon.mainhand
scoreboard players operation @e[type=minecraft:armor_stand,tag=kmtool_selected,tag=kmtool_new,limit=1] kmtool_damage = @s kmtool_damage
tag @e[type=minecraft:armor_stand,tag=kmtool_selected,tag=kmtool_new] remove kmtool_new

# Keep the hidden backup alive while the player is holding right click.
scoreboard players operation @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] kmtool_last = #clock kmtool_clock

# Armor stands stay invisible, but equipped items normally still render.
# Scale the backup to Minecraft's minimum entity scale and keep it below the player.
attribute @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] minecraft:scale base set 0.0625
teleport @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] ~ ~-2 ~

tag @e[type=minecraft:armor_stand,tag=kmtool_selected] remove kmtool_selected
