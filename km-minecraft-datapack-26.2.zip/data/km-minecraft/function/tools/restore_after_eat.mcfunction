scoreboard players operation @s kmtool_damage = @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] kmtool_damage
item replace entity @s weapon.mainhand from entity @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1] weapon.mainhand
scoreboard players add @s kmtool_damage 25
execute store result storage km-minecraft:tool_runtime damage int 1 run scoreboard players get @s kmtool_damage
function km-minecraft:tools/apply_damage with storage km-minecraft:tool_runtime
kill @e[type=minecraft:armor_stand,tag=kmtool_selected,limit=1]
