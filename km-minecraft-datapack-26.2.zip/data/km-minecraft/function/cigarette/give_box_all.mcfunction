execute as @a run function km-minecraft:cigarette/give_box
