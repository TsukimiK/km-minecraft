advancement revoke @s only km-minecraft:cigarette/smoke
particle minecraft:campfire_cosy_smoke ~ ~1.45 ~ 0.22 0.12 0.22 0.01 8 force @a[distance=..32]
playsound minecraft:block.fire.extinguish player @a[distance=..16] ~ ~ ~ 0.35 1.7
