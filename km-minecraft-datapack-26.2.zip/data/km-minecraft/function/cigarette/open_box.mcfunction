advancement revoke @s only km-minecraft:cigarette/open_box
function km-minecraft:cigarette/give_cigarettes
playsound minecraft:item.bundle.remove_one player @s ~ ~ ~ 0.8 1.1
particle minecraft:happy_villager ~ ~1.0 ~ 0.25 0.3 0.25 0.05 8 force @s
tellraw @s [{"text":"[煙草] ","color":"gold"},{"text":"箱を開封し、煙草を10本取り出しました","color":"green"}]
