# Production mode: public /trigger acquisition is disabled.
