recipe give @s km-minecraft:cigarette/box
