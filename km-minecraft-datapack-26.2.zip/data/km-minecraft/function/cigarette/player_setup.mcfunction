# Recipes are unlocked by acquiring the relevant farming item.
