function km-minecraft:armor/give/daikon_helmet
function km-minecraft:armor/give/daikon_chestplate
function km-minecraft:armor/give/daikon_leggings
function km-minecraft:armor/give/daikon_boots
