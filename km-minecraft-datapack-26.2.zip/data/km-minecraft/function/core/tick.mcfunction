function km-minecraft:farming/tick
