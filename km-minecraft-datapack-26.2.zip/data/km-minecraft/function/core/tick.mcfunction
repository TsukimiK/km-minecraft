function km-minecraft:farming/tick
function km-minecraft:tools/tick
execute as @a if items entity @s weapon.mainhand *[minecraft:custom_data~{km_minecraft:{asahatamon_omnitool:true}}] run function km-minecraft:asahatamon/omnitool_tick
function km-minecraft:throwing/tick
