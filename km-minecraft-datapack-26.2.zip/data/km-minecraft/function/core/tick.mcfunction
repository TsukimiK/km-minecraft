
function km-minecraft:farming/tick
function km-minecraft:tools/tick
