function km-minecraft:cigarette/load
function km-minecraft:farming/load
