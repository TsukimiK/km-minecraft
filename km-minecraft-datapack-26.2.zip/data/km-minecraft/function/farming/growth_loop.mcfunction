
execute as @e[type=minecraft:interaction,tag=km_farm_crop] at @s run function km-minecraft:farming/crop/maintenance
schedule function km-minecraft:farming/growth_loop 20t replace
