# Only immature crops participate in natural growth.
# Water-queued crops are frozen until their queued harvest is processed.
execute as @e[type=minecraft:interaction,tag=km_farm_crop,tag=km_stage0,tag=!km_water_candidate] at @s run function km-minecraft:farming/crop/try_grow
execute as @e[type=minecraft:interaction,tag=km_farm_crop,tag=km_stage1,tag=!km_water_candidate] at @s run function km-minecraft:farming/crop/try_grow

schedule function km-minecraft:farming/growth_loop 100t replace
