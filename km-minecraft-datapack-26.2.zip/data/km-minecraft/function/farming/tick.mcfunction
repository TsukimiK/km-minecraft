# One nearby crop scan per player/tick.
# The crop handler checks both left-click and right-click state.
execute as @a at @s as @e[type=minecraft:interaction,tag=km_farm_crop,distance=..6] at @s run function km-minecraft:farming/crop/handle_input
