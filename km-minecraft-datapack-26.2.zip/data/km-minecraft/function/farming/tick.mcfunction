
execute as @e[type=minecraft:interaction,tag=km_farm_crop] at @s if data entity @s attack run function km-minecraft:farming/crop/attack
execute as @e[type=minecraft:interaction,tag=km_farm_crop] at @s if data entity @s interaction run function km-minecraft:farming/crop/interact
