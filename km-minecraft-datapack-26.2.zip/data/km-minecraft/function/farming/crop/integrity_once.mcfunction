scoreboard players operation @s kmfarm_integrity_seen = #integrity_cycle kmfarm_integrity_seen
function km-minecraft:farming/crop/integrity_check
