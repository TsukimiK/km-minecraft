tag @s remove km_stage1
tag @s add km_stage2
function km-minecraft:farming/crop/refresh_visual
