# Water-queued mature crops give their normal harvest.
execute if entity @s[tag=km_stage2] run return run function km-minecraft:farming/crop/harvest

# Water-queued immature crops return one seed.
function km-minecraft:farming/crop/break_immature
