execute unless entity @s[gamemode=creative] run clear @s minecraft:bone_meal 1
execute as @e[type=minecraft:interaction,tag=km_farm_crop,distance=..0.10,limit=1,sort=nearest] at @s run function km-minecraft:farming/crop/grow_one
data remove entity @e[type=minecraft:interaction,tag=km_farm_crop,distance=..0.10,limit=1,sort=nearest] interaction
