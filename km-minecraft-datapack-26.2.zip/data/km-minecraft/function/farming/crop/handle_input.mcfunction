# Left-click has priority.
execute if data entity @s attack run return run function km-minecraft:farming/crop/attack

# Right-click is bone-meal handling only; mature crops are not harvested.
execute if data entity @s interaction run function km-minecraft:farming/crop/interact
