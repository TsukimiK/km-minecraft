# Mark this crop as scanned for the current water cycle before testing the block.
scoreboard players operation @s kmfarm_water_seen = #water_cycle kmfarm_water_seen

# minecraft:water matches both source and flowing water states.
execute if block ~ ~ ~ minecraft:water run tag @s add km_water_candidate
