loot spawn ~ ~0.15 ~ loot km-minecraft:farming/seed_one
execute unless entity @s[tag=km_water_candidate] run playsound minecraft:block.grass.break block @a[distance=..10] ~ ~ ~ 0.55 1.25
kill @e[type=minecraft:item_display,tag=km_farm_visual,distance=..0.06]
kill @s
