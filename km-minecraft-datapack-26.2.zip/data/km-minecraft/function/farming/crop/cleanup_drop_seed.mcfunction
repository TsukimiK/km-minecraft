
loot spawn ~ ~0.15 ~ loot km-minecraft:farming/seed_one
kill @e[type=minecraft:item_display,tag=km_farm_visual,distance=..0.06]
kill @s
