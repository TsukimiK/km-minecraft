
execute store result score #grow kmfarm_rng run random value 1..90
execute if score #grow kmfarm_rng matches 1 run function km-minecraft:farming/crop/grow_one
