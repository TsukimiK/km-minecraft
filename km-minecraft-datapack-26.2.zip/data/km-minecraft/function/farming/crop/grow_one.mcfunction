execute if entity @s[tag=km_stage1] run return run function km-minecraft:farming/crop/stage1_to_2
execute if entity @s[tag=km_stage0] run return run function km-minecraft:farming/crop/stage0_to_1
