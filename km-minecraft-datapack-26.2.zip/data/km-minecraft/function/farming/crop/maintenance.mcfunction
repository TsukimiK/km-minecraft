# Compatibility wrapper for an older scheduled growth loop.
function km-minecraft:farming/crop/integrity_check
