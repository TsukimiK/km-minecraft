
execute unless block ~ ~-1 ~ minecraft:farmland run return run function km-minecraft:farming/crop/cleanup_drop_seed
execute unless block ~ ~ ~ minecraft:air run return run function km-minecraft:farming/crop/cleanup_drop_seed
execute if entity @s[tag=km_stage1] run function km-minecraft:farming/crop/try_grow
execute if entity @s[tag=km_stage0] run function km-minecraft:farming/crop/try_grow
