tag @s remove km_stage0
tag @s add km_stage1
function km-minecraft:farming/crop/refresh_visual
