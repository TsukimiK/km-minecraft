# Mature plants keep their normal harvest value when the farmland/block state invalidates them.
execute if entity @s[tag=km_stage2] run return run function km-minecraft:farming/crop/harvest

# Immature plants return one seed.
function km-minecraft:farming/crop/break_immature
