# Right-click is reserved for bone meal. Mature crops are NOT harvested by right-click.
execute if entity @s[tag=km_stage0] on target if items entity @s weapon.mainhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage0] on target if items entity @s weapon.offhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage1] on target if items entity @s weapon.mainhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage1] on target if items entity @s weapon.offhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player

# Clear the interaction record for every other right-click.
data remove entity @s interaction
