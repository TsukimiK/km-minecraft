
execute if entity @s[tag=km_stage0] on target if items entity @s weapon.mainhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage0] on target if items entity @s weapon.offhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage1] on target if items entity @s weapon.mainhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage1] on target if items entity @s weapon.offhand minecraft:bone_meal run return run function km-minecraft:farming/crop/bone_meal_player
execute if entity @s[tag=km_stage2] run return run function km-minecraft:farming/crop/harvest
data remove entity @s interaction
