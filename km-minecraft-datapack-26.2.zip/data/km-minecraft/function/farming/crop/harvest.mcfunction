
execute if entity @s[tag=km_normal] run loot spawn ~ ~0.15 ~ loot km-minecraft:farming/harvest_normal
execute if entity @s[tag=km_rare] run loot spawn ~ ~0.15 ~ loot km-minecraft:farming/harvest_rare
playsound minecraft:block.grass.break block @a[distance=..10] ~ ~ ~ 0.65 1.15
kill @e[type=minecraft:item_display,tag=km_farm_visual,distance=..0.06]
kill @s
