
execute if entity @s[tag=km_stage2] run return run function km-minecraft:farming/crop/harvest
function km-minecraft:farming/crop/break_immature
