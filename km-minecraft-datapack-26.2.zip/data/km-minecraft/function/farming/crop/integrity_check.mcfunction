tag @s remove km_integrity_candidate

# Lost farmland: clean up the custom crop.
execute unless block ~ ~-1 ~ minecraft:farmland run return run function km-minecraft:farming/crop/cleanup_invalid

# Air is valid. Water is handled by the dedicated water-harvest queue.
# Any other block occupying the crop space is treated as invalid.
execute unless block ~ ~ ~ minecraft:air unless block ~ ~ ~ minecraft:water run return run function km-minecraft:farming/crop/cleanup_invalid
