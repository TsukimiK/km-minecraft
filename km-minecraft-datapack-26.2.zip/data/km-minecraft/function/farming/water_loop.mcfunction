# New scan generation. One crop can pass the water block test only once per cycle,
# even if several players' 32-block areas overlap.
scoreboard players add #water_cycle kmfarm_water_seen 1

execute as @a at @s as @e[type=minecraft:interaction,tag=km_farm_crop,tag=!km_water_candidate,distance=..32] at @s unless score @s kmfarm_water_seen = #water_cycle kmfarm_water_seen run function km-minecraft:farming/crop/water_detect

# One aggregated harvest sound per second instead of up to 64 sounds.
execute as @e[type=minecraft:interaction,tag=km_farm_crop,tag=km_water_candidate,limit=1,sort=arbitrary] at @s run playsound minecraft:block.grass.break block @a[distance=..10] ~ ~ ~ 0.65 1.15

# Global burst cap: at most 64 queued crops per second.
execute as @e[type=minecraft:interaction,tag=km_farm_crop,tag=km_water_candidate,limit=64,sort=arbitrary] at @s run function km-minecraft:farming/crop/water_harvest

schedule function km-minecraft:farming/water_loop 20t replace
