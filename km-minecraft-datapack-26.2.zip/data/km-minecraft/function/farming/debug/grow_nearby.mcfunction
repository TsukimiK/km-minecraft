execute as @e[type=minecraft:interaction,tag=km_farm_crop,distance=..6] at @s run function km-minecraft:farming/crop/grow_one
