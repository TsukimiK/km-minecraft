scoreboard objectives add kmfarm_rng dummy
scoreboard objectives add kmfarm_water_seen dummy
scoreboard objectives add kmfarm_integrity_seen dummy

# Rebuild crop visuals cleanly after datapack/server reload.
kill @e[type=minecraft:item_display,tag=km_farm_visual]
execute as @e[type=minecraft:interaction,tag=km_farm_crop] at @s run function km-minecraft:farming/crop/refresh_visual

# Stagger slower jobs so they do not all spike on the same tick.
schedule function km-minecraft:farming/water_loop 20t replace
schedule function km-minecraft:farming/integrity_loop 60t replace
schedule function km-minecraft:farming/growth_loop 100t replace
