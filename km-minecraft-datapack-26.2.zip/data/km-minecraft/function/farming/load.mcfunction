scoreboard objectives add kmfarm_rng dummy
execute as @e[type=minecraft:interaction,tag=km_farm_crop] at @s run function km-minecraft:farming/crop/refresh_visual
schedule function km-minecraft:farming/growth_loop 20t replace
