# One integrity check per crop per cycle, even with overlapping players.
scoreboard players add #integrity_cycle kmfarm_integrity_seen 1

execute as @a at @s as @e[type=minecraft:interaction,tag=km_farm_crop,tag=!km_water_candidate,distance=..32] at @s unless score @s kmfarm_integrity_seen = #integrity_cycle kmfarm_integrity_seen run function km-minecraft:farming/crop/integrity_once

schedule function km-minecraft:farming/integrity_loop 100t replace
