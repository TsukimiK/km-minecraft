
summon minecraft:interaction ~ ~ ~ {Tags:["km_farm_crop","km_daikon","km_normal","km_stage0"],width:0.86f,height:1.0f,response:1b}
execute as @e[type=minecraft:interaction,tag=km_farm_crop,tag=km_normal,tag=km_stage0,distance=..0.10,limit=1,sort=nearest] at @s run function km-minecraft:farming/crop/refresh_visual
