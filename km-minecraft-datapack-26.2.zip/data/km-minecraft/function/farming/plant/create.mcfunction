setblock ~ ~ ~ minecraft:air
execute if entity @e[type=minecraft:interaction,tag=km_farm_crop,distance=..0.20,limit=1] run return run function km-minecraft:farming/plant/occupied
execute if entity @s[tag=km_force_rare_crop] run return run function km-minecraft:farming/plant/create_rare
execute store result score #plant kmfarm_rng run random value 1..100
execute if score #plant kmfarm_rng matches 1 run function km-minecraft:farming/plant/create_rare
execute unless score #plant kmfarm_rng matches 1 run function km-minecraft:farming/plant/create_normal
