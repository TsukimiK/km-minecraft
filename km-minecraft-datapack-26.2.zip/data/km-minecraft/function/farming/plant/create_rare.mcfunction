
summon minecraft:interaction ~ ~ ~ {Tags:["km_farm_crop","km_daikon","km_rare","km_stage0"],width:1.20f,height:1.35f,response:1b}
execute as @e[type=minecraft:interaction,tag=km_farm_crop,tag=km_rare,tag=km_stage0,distance=..0.10,limit=1,sort=nearest] at @s run function km-minecraft:farming/crop/refresh_visual
