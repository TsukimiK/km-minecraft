execute unless entity @s[gamemode=creative] run loot give @s loot km-minecraft:farming/seed_one
