
advancement revoke @s only km-minecraft:farming/plant_daikon
execute anchored eyes positioned ^ ^ ^0.20 run function km-minecraft:farming/plant/raycast
