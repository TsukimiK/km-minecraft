
execute if block ~ ~ ~ minecraft:wheat[age=0] if block ~ ~-1 ~ minecraft:farmland run return run execute align xyz positioned ~0.5 ~ ~0.5 run function km-minecraft:farming/plant/create
execute if entity @s[distance=..7] positioned ^ ^ ^0.10 run function km-minecraft:farming/plant/raycast
