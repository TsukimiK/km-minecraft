advancement revoke @s only km-minecraft:farming/plant_daikon_rare
tag @s add km_force_rare_crop
execute anchored eyes positioned ^ ^ ^0.20 run function km-minecraft:farming/plant/raycast
tag @s remove km_force_rare_crop
