Daikon carrier item changed from minecraft:disc_fragment_5 to minecraft:poisonous_potato.
This removes the built-in "Music Disc - 5" tooltip line while preserving custom model, food components, and cooking recipes.
Existing already-harvested old daikon stacks remain disc_fragment_5-based; harvest new ones after /reload to get the fixed item.
