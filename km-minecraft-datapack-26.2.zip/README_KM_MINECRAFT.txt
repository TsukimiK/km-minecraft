KM Minecraft 26.2 - unified pack

Modules:
- cigarette
- farming / daikon + Asahatamon

Farming spec:
- Plant 大根の種 on farmland.
- 99% normal / 1% rare, fixed when planted.
- 3 visual stages (stage 0, 1, 2). Stage 2 is harvestable.
- Natural growth: checked once per second; 1/90 chance per check for each transition.
- Bone meal: right-click crop to advance one stage.
- Harvest: left-click or right-click mature crop.
- Normal harvest: 大根 x2-4 + 大根の種 x2-3.
- Rare harvest: あさはたもん x2-4 + 大根の種 x2-3.
- Immature left-click break: 大根の種 x1.
- Cooking: furnace, smoker, and campfire.

Food:
- 大根: hunger 4 (=2 icons), saturation 3.2
- あさはたもん: hunger 6 (=3 icons), saturation 7.2
- 焼き大根: hunger 7 (=3.5 icons), saturation 9.8
- 焼きあさはたもん: hunger 10 (=5 icons), saturation 16.0

Test commands:
/function km-minecraft:farming/give_seeds
/function km-minecraft:farming/debug/grow_nearby

Implementation note:
Raw custom foods use rare inert vanilla carrier items internally (poisonous_potato / echo_shard) so standard furnace/smoker/campfire recipes can be used without mods. Do not add separate cooking recipes for those two vanilla carrier items while this module is enabled.
