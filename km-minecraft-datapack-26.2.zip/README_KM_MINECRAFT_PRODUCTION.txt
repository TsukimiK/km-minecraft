km-minecraft 26.2 - Production Clean Build

Active systems:
- Vegeter cigarette / BOX
- Daikon farming + rare Asahatamon
- Daikon tools: sword, pickaxe, axe, shovel

Intentional compatibility code:
- tool custom_data thirdperson_fix flag
  One-time normalization marker for older daikon tools.

Admin functions:
- /function km-minecraft:cigarette/give_box
- /function km-minecraft:farming/give_seeds
- /function km-minecraft:farming/debug/give_rare_seeds
- /function km-minecraft:farming/debug/grow_nearby
- /function km-minecraft:tools/give_all

Farming performance profile:
- Old backpack-era migration compatibility has been removed.
- Nearby input: one crop entity search per player/tick within 6 blocks.
- Left-click harvest only; right-click is bone-meal only.
- Natural growth: stage0/stage1 only, every 5 seconds, 1/60 chance.
- Mature stage2 crops do not run natural-growth logic.
- Water detection: every 1 second within 32 blocks of players.
- Overlapping players do not repeat the water block test on the same crop in one cycle.
- Source and flowing water are both supported.
- Water harvest queue is capped at 64 crops/second.
- Water harvest uses one aggregated break sound per second instead of one sound per crop.
- Integrity checks: every 5 seconds within 32 blocks.
- Overlapping players do not repeat integrity checks on the same crop in one cycle.
