km-minecraft 26.2 - Production Datapack

Active systems:
- Vegeter BOX / cigarette
- Daikon farming
- Rare Asahatamon crop
- Daikon sword / pickaxe / axe / shovel
- Daikon helmet / chestplate / leggings / boots
- Daikon shield

Farming:
- Harvest: left-click only
- Right-click: bone meal only
- Natural growth: stage0/stage1 only, every 5 seconds
- Mature stage2 does not run growth logic
- Water harvesting supported
- Water harvest processing capped at 64 crops/second
- Nearby integrity checks are de-duplicated for overlapping players

Daikon tools:
- Iron-equivalent tool performance
- Durability: 220
- Right-click hold to eat
- Eating consumes fixed 25 durability
- Food particles disabled
- Third-person duplicate-item visual fix included

Daikon armor:
- Defense: iron-equivalent (2 / 6 / 5 / 2)
- Durability: copper-equivalent (121 / 176 / 165 / 143)
- Enchantability: iron-equivalent
- Not edible
- Material repair disabled; Unbreaking / Mending supported

Daikon shield:
- Vanilla shield mechanics and durability
- Vanilla shield renderer / positioning
- Fixed Daikon appearance
- Recipe uses Daikon in place of the iron ingot

Admin / test functions:
- /function km-minecraft:cigarette/give_box
- /function km-minecraft:farming/give_seeds
- /function km-minecraft:farming/debug/give_rare_seeds
- /function km-minecraft:farming/debug/grow_nearby
- /function km-minecraft:tools/give_all
- /function km-minecraft:armor/give_all
- /function km-minecraft:shield/give
