All KM Minecraft custom items and farming growth-stage models use true-flat front/back-only geometry.
Growth stages converted:
- normal_stage_0.json
- normal_stage_1.json
- normal_stage_2.json
- rare_stage_0.json
- rare_stage_1.json
- rare_stage_2.json
