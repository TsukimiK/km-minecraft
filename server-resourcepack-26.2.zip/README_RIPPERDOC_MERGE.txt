KM Minecraft 26.2 Resource Pack + Ripperdoc Cyberware v1.0.0
Merged resource pack.
Base: km-minecraft-resourcepack-26.2 (1).zip
Added namespace: assets/ripperdoc/
pack.mcmeta unified for Minecraft Java 26.2.
