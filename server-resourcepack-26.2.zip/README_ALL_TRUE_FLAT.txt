All compatible KM Minecraft custom item models use true-flat front/back-only geometry.
This removes the per-pixel side extrusion streaks caused by minecraft:item/generated.
Converted additional models:
- cigarette/cigarette.json
- cigarette/box.json
