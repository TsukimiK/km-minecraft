True-flat farming item models.
Replaced minecraft:item/generated extrusion with a custom two-face plane.
No side faces, no acrylic edge, no per-pixel extrusion streaks.
