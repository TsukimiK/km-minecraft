KM Minecraft 26.2 Resource Pack
Modules: cigarette, farming.
Farming textures use the user-approved normal/rare crop and food artwork.
