attribute @s minecraft:movement_speed modifier remove ripperdoc:zandevistan
scoreboard players set @s rd_zande 0
scoreboard players set @s rd_miss_z 0
tag @s remove rd_zande
function ripperdoc:visual/zandevistan_inactive
