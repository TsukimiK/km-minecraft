advancement revoke @s only ripperdoc:use_berserk
scoreboard players set @s rd_seen_b 2
scoreboard players add @s rd_hold_b 1
execute if score @s rd_hold_b matches 32.. run function ripperdoc:use/berserk_finish
