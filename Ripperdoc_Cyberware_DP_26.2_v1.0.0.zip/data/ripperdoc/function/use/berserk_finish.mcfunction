# 32-tick drink completed for berserk. No item consumption occurs.
scoreboard players set @s rd_hold_b 0
scoreboard players set @s rd_miss_b 0
scoreboard players set @s rd_seen_b 0
tag @s remove rd_use_offhand
execute unless items entity @s weapon.mainhand minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] if items entity @s weapon.offhand minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run tag @s add rd_use_offhand
tag @s remove rd_toggle_off
execute if entity @s[tag=rd_berserk] run tag @s add rd_toggle_off
execute if entity @s[tag=rd_toggle_off] run function ripperdoc:berserk/end
execute unless entity @s[tag=rd_toggle_off] run scoreboard players set @s rd_berserk 6000
execute unless entity @s[tag=rd_toggle_off] run tag @s add rd_berserk
execute unless entity @s[tag=rd_toggle_off] run attribute @s minecraft:attack_damage modifier remove ripperdoc:berserk_damage
execute unless entity @s[tag=rd_toggle_off] run attribute @s minecraft:attack_damage modifier add ripperdoc:berserk_damage 6 add_value
execute unless entity @s[tag=rd_toggle_off] run attribute @s minecraft:block_break_speed modifier remove ripperdoc:berserk_mining
execute unless entity @s[tag=rd_toggle_off] run attribute @s minecraft:block_break_speed modifier add ripperdoc:berserk_mining 0.6 add_multiplied_base
execute unless entity @s[tag=rd_toggle_off] run function ripperdoc:visual/berserk_active
execute if entity @s[tag=rd_use_offhand] run loot replace entity @s weapon.offhand loot ripperdoc:items/berserk
execute unless entity @s[tag=rd_use_offhand] run loot replace entity @s weapon.mainhand loot ripperdoc:items/berserk
execute if entity @s[tag=rd_berserk,tag=rd_use_offhand] run item modify entity @s weapon.offhand ripperdoc:berserk_active
execute if entity @s[tag=rd_berserk,tag=!rd_use_offhand] run item modify entity @s weapon.mainhand ripperdoc:berserk_active
tag @s remove rd_toggle_off
tag @s remove rd_use_offhand
