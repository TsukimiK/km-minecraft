# 32-tick drink completed for aquatic. No item consumption occurs.
scoreboard players set @s rd_hold_a 0
scoreboard players set @s rd_miss_a 0
scoreboard players set @s rd_seen_a 0
tag @s remove rd_use_offhand
execute unless items entity @s weapon.mainhand minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] if items entity @s weapon.offhand minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run tag @s add rd_use_offhand
tag @s remove rd_toggle_off
execute if entity @s[tag=rd_aqua] run tag @s add rd_toggle_off
execute if entity @s[tag=rd_toggle_off] run function ripperdoc:aquatic/end
execute unless entity @s[tag=rd_toggle_off] run scoreboard players set @s rd_aqua 6000
execute unless entity @s[tag=rd_toggle_off] run tag @s add rd_aqua
execute unless entity @s[tag=rd_toggle_off] run execute store result score @s rd_yprev run data get entity @s Pos[1] 1000
execute unless entity @s[tag=rd_toggle_off] run scoreboard players operation @s rd_y = @s rd_yprev
execute unless entity @s[tag=rd_toggle_off] run function ripperdoc:visual/aquatic_active
execute if entity @s[tag=rd_use_offhand] run loot replace entity @s weapon.offhand loot ripperdoc:items/aquatic
execute unless entity @s[tag=rd_use_offhand] run loot replace entity @s weapon.mainhand loot ripperdoc:items/aquatic
execute if entity @s[tag=rd_aqua,tag=rd_use_offhand] run item modify entity @s weapon.offhand ripperdoc:aquatic_active
execute if entity @s[tag=rd_aqua,tag=!rd_use_offhand] run item modify entity @s weapon.mainhand ripperdoc:aquatic_active
tag @s remove rd_toggle_off
tag @s remove rd_use_offhand
