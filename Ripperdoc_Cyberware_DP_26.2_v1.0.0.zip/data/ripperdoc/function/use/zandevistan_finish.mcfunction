# 32-tick drink completed for zandevistan. No item consumption occurs.
scoreboard players set @s rd_hold_z 0
scoreboard players set @s rd_miss_z 0
scoreboard players set @s rd_seen_z 0
tag @s remove rd_use_offhand
execute unless items entity @s weapon.mainhand minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] if items entity @s weapon.offhand minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run tag @s add rd_use_offhand
tag @s remove rd_toggle_off
execute if entity @s[tag=rd_zande] run tag @s add rd_toggle_off
execute if entity @s[tag=rd_toggle_off] run function ripperdoc:zande/end
execute unless entity @s[tag=rd_toggle_off] run scoreboard players set @s rd_zande 6000
execute unless entity @s[tag=rd_toggle_off] run tag @s add rd_zande
execute unless entity @s[tag=rd_toggle_off] run attribute @s minecraft:movement_speed modifier remove ripperdoc:zandevistan
execute unless entity @s[tag=rd_toggle_off] run attribute @s minecraft:movement_speed modifier add ripperdoc:zandevistan 0.5 add_multiplied_base
execute unless entity @s[tag=rd_toggle_off] run function ripperdoc:visual/zandevistan_active
execute if entity @s[tag=rd_use_offhand] run loot replace entity @s weapon.offhand loot ripperdoc:items/zandevistan
execute unless entity @s[tag=rd_use_offhand] run loot replace entity @s weapon.mainhand loot ripperdoc:items/zandevistan
execute if entity @s[tag=rd_zande,tag=rd_use_offhand] run item modify entity @s weapon.offhand ripperdoc:zandevistan_active
execute if entity @s[tag=rd_zande,tag=!rd_use_offhand] run item modify entity @s weapon.mainhand ripperdoc:zandevistan_active
tag @s remove rd_toggle_off
tag @s remove rd_use_offhand
