advancement revoke @s only ripperdoc:use_zandevistan
scoreboard players set @s rd_seen_z 2
scoreboard players add @s rd_hold_z 1
execute if score @s rd_hold_z matches 32.. run function ripperdoc:use/zandevistan_finish
