advancement revoke @s only ripperdoc:use_aquatic
scoreboard players set @s rd_seen_a 2
scoreboard players add @s rd_hold_a 1
execute if score @s rd_hold_a matches 32.. run function ripperdoc:use/aquatic_finish
