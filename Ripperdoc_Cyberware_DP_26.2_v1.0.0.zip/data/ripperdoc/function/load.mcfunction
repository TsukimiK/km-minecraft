# Ripperdoc Cyberware v1.0.0 - Minecraft Java 26.2
scoreboard objectives add rd_zande dummy
scoreboard objectives add rd_berserk dummy
scoreboard objectives add rd_aqua dummy
scoreboard objectives add rd_air dummy
scoreboard objectives add rd_jused dummy
scoreboard objectives add rd_impulse dummy
scoreboard objectives add rd_vy dummy
scoreboard objectives add rd_death deathCount
scoreboard objectives add rd_pid dummy
scoreboard objectives add rd_owner dummy
scoreboard objectives add rd_clock dummy
scoreboard objectives add rd_y dummy
scoreboard objectives add rd_yprev dummy
scoreboard objectives add rd_init dummy
scoreboard objectives add rd_has_z dummy
scoreboard objectives add rd_has_b dummy
scoreboard objectives add rd_has_a dummy
scoreboard objectives add rd_miss_z dummy
scoreboard objectives add rd_miss_b dummy
scoreboard objectives add rd_miss_a dummy
scoreboard objectives add rd_seen_z dummy
scoreboard objectives add rd_seen_b dummy
scoreboard objectives add rd_seen_a dummy
scoreboard objectives add rd_hold_z dummy
scoreboard objectives add rd_hold_b dummy
scoreboard objectives add rd_hold_a dummy
scoreboard objectives add rd_jump_prev dummy
scoreboard objectives add rd_jumpstat minecraft.custom:minecraft.jump
scoreboard objectives add rd_moon_ground dummy
scoreboard objectives add rd_moon_age dummy

# Reinitialize online players and remove any temporary AQUATIC platforms left by a reload.
scoreboard players reset * rd_init
kill @e[type=minecraft:shulker,tag=rd_aq_platform]
execute as @a run function ripperdoc:player/init
scoreboard players set #clock rd_clock 0
scoreboard players set #vis rd_clock 0
