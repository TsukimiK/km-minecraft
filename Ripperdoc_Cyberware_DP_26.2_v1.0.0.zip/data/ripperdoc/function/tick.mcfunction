# Initialize new players once.
execute as @a unless score @s rd_init matches 1 run function ripperdoc:player/init

# Death cleanup.
execute as @a[scores={rd_death=1..}] run function ripperdoc:death_cleanup
scoreboard players set @a[scores={rd_death=1..}] rd_death 0

# Reusable implant drink timers. using_item refreshes rd_seen_* while held.
scoreboard players remove @a[scores={rd_seen_z=1..}] rd_seen_z 1
scoreboard players remove @a[scores={rd_seen_b=1..}] rd_seen_b 1
scoreboard players remove @a[scores={rd_seen_a=1..}] rd_seen_a 1
scoreboard players set @a[scores={rd_seen_z=0}] rd_hold_z 0
scoreboard players set @a[scores={rd_seen_b=0}] rd_hold_b 0
scoreboard players set @a[scores={rd_seen_a=0}] rd_hold_a 0

# Active implants end if the owner no longer carries them.
function ripperdoc:ownership_tick

# Five-minute ability timers.
execute as @a[tag=rd_zande,scores={rd_zande=1}] run function ripperdoc:zande/end
scoreboard players remove @a[tag=rd_zande,scores={rd_zande=2..}] rd_zande 1
execute as @a[tag=rd_berserk,scores={rd_berserk=1}] run function ripperdoc:berserk/end
scoreboard players remove @a[tag=rd_berserk,scores={rd_berserk=2..}] rd_berserk 1
execute as @a[tag=rd_aqua,scores={rd_aqua=1}] run function ripperdoc:aquatic/end
scoreboard players remove @a[tag=rd_aqua,scores={rd_aqua=2..}] rd_aqua 1

# MOONTECH equip state and movement logic.
execute as @a[tag=!rd_moontech] if items entity @s armor.feet minecraft:netherite_boots[minecraft:custom_data~{ripperdoc_id:"moontech"}] run function ripperdoc:moontech/equip
execute as @a[tag=rd_moontech] unless items entity @s armor.feet minecraft:netherite_boots[minecraft:custom_data~{ripperdoc_id:"moontech"}] run function ripperdoc:moontech/unequip
execute as @a[tag=rd_moontech] at @s run function ripperdoc:moontech/tick

# AQUATIC surface logic only for active users.
execute as @a[tag=rd_aqua] at @s run function ripperdoc:aquatic/tick

# Orphan AQUATIC platform cleanup every 5 seconds.
scoreboard players add #clock rd_clock 1
execute if score #clock rd_clock matches 100.. run function ripperdoc:aquatic/platform/cleanup
execute if score #clock rd_clock matches 100.. run scoreboard players set #clock rd_clock 0

# Active/inactive item appearance sync every 0.5 seconds.
scoreboard players add #vis rd_clock 1
execute if score #vis rd_clock matches 10.. as @a run function ripperdoc:visual/sync
execute if score #vis rd_clock matches 10.. as @e[type=minecraft:item] run function ripperdoc:visual/normalize_dropped
execute if score #vis rd_clock matches 10.. run scoreboard players set #vis rd_clock 0

# SPACE edge detection only for MOONTECH wearers.
execute as @a[tag=rd_moontech] if predicate ripperdoc:is_jumping run tag @s add rd_jump_held
execute as @a[tag=rd_moontech] unless predicate ripperdoc:is_jumping run tag @s remove rd_jump_held
execute as @a[tag=!rd_moontech,tag=rd_jump_held] run tag @s remove rd_jump_held
