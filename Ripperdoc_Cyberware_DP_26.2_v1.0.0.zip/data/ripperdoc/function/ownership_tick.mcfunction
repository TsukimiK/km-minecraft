# Active implants must remain in this player's possession.
# A 3-tick grace window prevents accidental OFF while moving an item with the GUI cursor.

# ZANDEVISTAN
execute as @a[tag=rd_zande] store result score @s rd_has_z run clear @s minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] 0
execute as @a[tag=rd_zande,scores={rd_has_z=0}] if items entity @s player.cursor minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run scoreboard players set @s rd_has_z 1
execute as @a[tag=rd_zande,scores={rd_has_z=0}] if items entity @s weapon.offhand minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run scoreboard players set @s rd_has_z 1
execute as @a[tag=rd_zande,scores={rd_has_z=0}] if items entity @s player.crafting.* minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run scoreboard players set @s rd_has_z 1
execute as @a[tag=rd_zande,scores={rd_has_z=1..}] run scoreboard players set @s rd_miss_z 0
execute as @a[tag=rd_zande,scores={rd_has_z=0}] run scoreboard players add @s rd_miss_z 1
execute as @a[tag=rd_zande,scores={rd_miss_z=3..}] run function ripperdoc:zande/end

# BERSERK
execute as @a[tag=rd_berserk] store result score @s rd_has_b run clear @s minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] 0
execute as @a[tag=rd_berserk,scores={rd_has_b=0}] if items entity @s player.cursor minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run scoreboard players set @s rd_has_b 1
execute as @a[tag=rd_berserk,scores={rd_has_b=0}] if items entity @s weapon.offhand minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run scoreboard players set @s rd_has_b 1
execute as @a[tag=rd_berserk,scores={rd_has_b=0}] if items entity @s player.crafting.* minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run scoreboard players set @s rd_has_b 1
execute as @a[tag=rd_berserk,scores={rd_has_b=1..}] run scoreboard players set @s rd_miss_b 0
execute as @a[tag=rd_berserk,scores={rd_has_b=0}] run scoreboard players add @s rd_miss_b 1
execute as @a[tag=rd_berserk,scores={rd_miss_b=3..}] run function ripperdoc:berserk/end

# AQUATIC
execute as @a[tag=rd_aqua] store result score @s rd_has_a run clear @s minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] 0
execute as @a[tag=rd_aqua,scores={rd_has_a=0}] if items entity @s player.cursor minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run scoreboard players set @s rd_has_a 1
execute as @a[tag=rd_aqua,scores={rd_has_a=0}] if items entity @s weapon.offhand minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run scoreboard players set @s rd_has_a 1
execute as @a[tag=rd_aqua,scores={rd_has_a=0}] if items entity @s player.crafting.* minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run scoreboard players set @s rd_has_a 1
execute as @a[tag=rd_aqua,scores={rd_has_a=1..}] run scoreboard players set @s rd_miss_a 0
execute as @a[tag=rd_aqua,scores={rd_has_a=0}] run scoreboard players add @s rd_miss_a 1
execute as @a[tag=rd_aqua,scores={rd_miss_a=3..}] run function ripperdoc:aquatic/end
