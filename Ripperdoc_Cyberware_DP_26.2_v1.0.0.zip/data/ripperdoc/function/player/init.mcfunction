function ripperdoc:reset_player
execute unless score @s rd_pid matches 1.. run function ripperdoc:player/assign_id
execute store result score @s rd_yprev run data get entity @s Pos[1] 1000
scoreboard players operation @s rd_y = @s rd_yprev
scoreboard players operation @s rd_jump_prev = @s rd_jumpstat
scoreboard players set @s rd_init 1
function ripperdoc:visual/zandevistan_inactive
function ripperdoc:visual/berserk_inactive
function ripperdoc:visual/aquatic_inactive
