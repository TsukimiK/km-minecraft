
scoreboard players add #next rd_pid 1
scoreboard players operation @s rd_pid = #next rd_pid
