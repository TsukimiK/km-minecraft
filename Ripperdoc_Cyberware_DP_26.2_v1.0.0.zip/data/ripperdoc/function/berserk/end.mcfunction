attribute @s minecraft:attack_damage modifier remove ripperdoc:berserk_damage
attribute @s minecraft:block_break_speed modifier remove ripperdoc:berserk_mining
scoreboard players set @s rd_berserk 0
scoreboard players set @s rd_miss_b 0
tag @s remove rd_berserk
function ripperdoc:visual/berserk_inactive
