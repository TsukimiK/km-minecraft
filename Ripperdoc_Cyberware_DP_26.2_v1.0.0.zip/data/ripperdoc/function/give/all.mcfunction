
loot give @s loot ripperdoc:items/zandevistan
loot give @s loot ripperdoc:items/berserk
loot give @s loot ripperdoc:items/aquatic
loot give @s loot ripperdoc:items/moontech
