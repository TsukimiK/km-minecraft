loot give @s loot ripperdoc:items/berserk
