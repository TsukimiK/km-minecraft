loot give @s loot ripperdoc:items/aquatic
