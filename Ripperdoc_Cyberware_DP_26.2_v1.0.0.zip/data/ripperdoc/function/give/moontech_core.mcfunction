loot give @s loot ripperdoc:items/moontech_core
