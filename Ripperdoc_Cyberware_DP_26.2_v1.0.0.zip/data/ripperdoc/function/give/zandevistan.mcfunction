loot give @s loot ripperdoc:items/zandevistan
