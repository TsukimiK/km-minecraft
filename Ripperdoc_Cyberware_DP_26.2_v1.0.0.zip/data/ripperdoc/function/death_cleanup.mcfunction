execute if entity @s[tag=rd_zande] run function ripperdoc:zande/end
execute if entity @s[tag=rd_berserk] run function ripperdoc:berserk/end
execute if entity @s[tag=rd_aqua] run function ripperdoc:aquatic/end
execute if entity @s[tag=rd_moontech] run function ripperdoc:moontech/unequip
scoreboard players set @s rd_air 0
scoreboard players set @s rd_jused 0
scoreboard players set @s rd_impulse 0
scoreboard players set @s rd_moon_ground 0
scoreboard players set @s rd_moon_age 0
tag @s remove rd_moon_fall
tag @s remove rd_jump_held
