# Integer offsets are enough to hit every block layer while preserving the player's exact X/Z.
execute positioned ~ ~-1 ~ if block ~ ~ ~ minecraft:water if block ~ ~1 ~ #ripperdoc:air align y run function ripperdoc:aquatic/platform/ensure_landing
execute unless entity @s[tag=rd_aq_landing] positioned ~ ~-2 ~ if block ~ ~ ~ minecraft:water if block ~ ~1 ~ #ripperdoc:air align y run function ripperdoc:aquatic/platform/ensure_landing
execute unless entity @s[tag=rd_aq_landing] positioned ~ ~-3 ~ if block ~ ~ ~ minecraft:water if block ~ ~1 ~ #ripperdoc:air align y run function ripperdoc:aquatic/platform/ensure_landing
execute unless entity @s[tag=rd_aq_landing] positioned ~ ~-4 ~ if block ~ ~ ~ minecraft:water if block ~ ~1 ~ #ripperdoc:air align y run function ripperdoc:aquatic/platform/ensure_landing
