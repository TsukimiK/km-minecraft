function ripperdoc:aquatic/platform/remove_owned
scoreboard players set @s rd_aqua 0
scoreboard players set @s rd_miss_a 0
tag @s remove rd_aqua
tag @s remove rd_aqsurf
tag @s remove rd_aq_onwater
tag @s remove rd_aq_landing
function ripperdoc:visual/aquatic_inactive
