tag @s add rd_aqsurf
scoreboard players operation #pid rd_pid = @s rd_pid
# Only inspect platforms close to this player; no world-wide per-player search.
tag @e[type=minecraft:shulker,tag=rd_aq_platform,distance=..4] remove rd_aq_match
execute as @e[type=minecraft:shulker,tag=rd_aq_platform,distance=..4] if score @s rd_owner = #pid rd_pid run tag @s add rd_aq_match
execute unless entity @e[type=minecraft:shulker,tag=rd_aq_match,distance=..4,limit=1] run function ripperdoc:aquatic/platform/summon_follow
execute as @e[type=minecraft:shulker,tag=rd_aq_match,distance=..4] run tp @s ~ ~-1.0 ~
tag @e[type=minecraft:shulker,tag=rd_aq_match,distance=..4] remove rd_aq_match
