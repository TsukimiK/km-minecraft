# Called positioned at the base Y of a detected water-surface block.
tag @s add rd_aqsurf
tag @s add rd_aq_landing
scoreboard players operation #pid rd_pid = @s rd_pid
tag @e[type=minecraft:shulker,tag=rd_aq_platform,distance=..6] remove rd_aq_match
execute as @e[type=minecraft:shulker,tag=rd_aq_platform,distance=..6] if score @s rd_owner = #pid rd_pid run tag @s add rd_aq_match
execute unless entity @e[type=minecraft:shulker,tag=rd_aq_match,distance=..6,limit=1] run function ripperdoc:aquatic/platform/summon_landing
# Keep the landing platform directly under the player's current X/Z at the water-surface Y.
execute as @e[type=minecraft:shulker,tag=rd_aq_match,distance=..6] run tp @s ~ ~ ~
tag @e[type=minecraft:shulker,tag=rd_aq_match,distance=..6] remove rd_aq_match
