scoreboard players operation #pid rd_pid = @s rd_pid
# Normal cleanup is local. Any platform stranded by a teleport/logoff is caught by periodic orphan cleanup.
execute as @e[type=minecraft:shulker,tag=rd_aq_platform,distance=..6] if score @s rd_owner = #pid rd_pid run kill @s
tag @s remove rd_aqsurf
tag @s remove rd_aq_landing
