execute as @e[type=minecraft:shulker,tag=rd_aq_platform] at @s run function ripperdoc:aquatic/platform/validate
