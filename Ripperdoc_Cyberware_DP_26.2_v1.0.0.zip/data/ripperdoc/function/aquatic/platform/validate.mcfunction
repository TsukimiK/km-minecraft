tag @s add rd_aq_checking
tag @s remove rd_aq_keep
scoreboard players operation #owner rd_owner = @s rd_owner
# A legitimate platform always has its owner close by and marked as using a surface platform.
execute as @a[tag=rd_aqsurf,distance=..6] if score @s rd_pid = #owner rd_owner run tag @e[type=minecraft:shulker,tag=rd_aq_checking,limit=1] add rd_aq_keep
execute unless entity @s[tag=rd_aq_keep] run kill @s
tag @s remove rd_aq_checking
tag @s remove rd_aq_keep
