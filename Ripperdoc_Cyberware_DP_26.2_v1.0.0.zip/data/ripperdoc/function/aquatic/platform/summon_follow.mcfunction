summon minecraft:shulker ~ ~-1.0 ~ {Tags:["rd_aq_platform","rd_aq_new"],NoAI:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,PersistenceRequired:1b,Peek:0b,DeathLootTable:"ripperdoc:empty"}
scoreboard players operation @e[type=minecraft:shulker,tag=rd_aq_new,distance=..2,limit=1,sort=nearest] rd_owner = @s rd_pid
effect give @e[type=minecraft:shulker,tag=rd_aq_new,distance=..2,limit=1,sort=nearest] minecraft:invisibility infinite 0 true
tag @e[type=minecraft:shulker,tag=rd_aq_new,distance=..2,limit=1,sort=nearest] add rd_aq_match
tag @e[type=minecraft:shulker,tag=rd_aq_new,distance=..2,limit=1,sort=nearest] remove rd_aq_new
