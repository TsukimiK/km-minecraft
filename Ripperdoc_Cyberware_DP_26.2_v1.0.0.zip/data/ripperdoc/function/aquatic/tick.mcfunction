tag @s remove rd_aq_onwater
tag @s remove rd_aq_landing

# Track vertical movement only for players currently using AQUATIC.
execute store result score @s rd_y run data get entity @s Pos[1] 1000

# Normal water-surface state: feet are in air and water is immediately below.
execute at @s if block ~ ~ ~ #ripperdoc:air positioned ~ ~-0.08 ~ if block ~ ~ ~ minecraft:water at @s unless data entity @s RootVehicle unless entity @s[nbt={FallFlying:1b}] run tag @s add rd_aq_onwater
execute if entity @s[tag=rd_aq_onwater] run function ripperdoc:aquatic/platform/ensure

# While descending, pre-create/reposition the invisible platform BEFORE the player enters the water.
# This fixes jump landings without vertically teleporting the player.
execute unless entity @s[tag=rd_aq_onwater] if score @s rd_y < @s rd_yprev unless data entity @s RootVehicle unless entity @s[nbt={FallFlying:1b}] run function ripperdoc:aquatic/landing/try

# If neither standing nor descending toward a valid water surface, remove the local platform.
execute unless entity @s[tag=rd_aq_onwater] unless entity @s[tag=rd_aq_landing] if entity @s[tag=rd_aqsurf] run function ripperdoc:aquatic/platform/remove_owned

scoreboard players operation @s rd_yprev = @s rd_y
tag @s remove rd_aq_onwater
tag @s remove rd_aq_landing
