execute if items entity @s contents minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan",ripperdoc_active:true}] run item modify entity @s contents ripperdoc:zandevistan_inactive
execute if items entity @s contents minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk",ripperdoc_active:true}] run item modify entity @s contents ripperdoc:berserk_inactive
execute if items entity @s contents minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic",ripperdoc_active:true}] run item modify entity @s contents ripperdoc:aquatic_inactive
