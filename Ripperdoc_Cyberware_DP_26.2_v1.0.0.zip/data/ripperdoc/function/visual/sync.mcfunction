# Refresh only implant types this player currently carries.
execute store result score @s rd_has_z run clear @s minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] 0
execute if score @s rd_has_z matches 0 if items entity @s player.cursor minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run scoreboard players set @s rd_has_z 1
execute if score @s rd_has_z matches 0 if items entity @s weapon.offhand minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run scoreboard players set @s rd_has_z 1
execute if score @s rd_has_z matches 0 if items entity @s player.crafting.* minecraft:echo_shard[minecraft:custom_data~{ripperdoc_id:"zandevistan"}] run scoreboard players set @s rd_has_z 1
execute if score @s rd_has_z matches 1.. if entity @s[tag=rd_zande] run function ripperdoc:visual/zandevistan_active
execute if score @s rd_has_z matches 1.. unless entity @s[tag=rd_zande] run function ripperdoc:visual/zandevistan_inactive

execute store result score @s rd_has_b run clear @s minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] 0
execute if score @s rd_has_b matches 0 if items entity @s player.cursor minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run scoreboard players set @s rd_has_b 1
execute if score @s rd_has_b matches 0 if items entity @s weapon.offhand minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run scoreboard players set @s rd_has_b 1
execute if score @s rd_has_b matches 0 if items entity @s player.crafting.* minecraft:blaze_rod[minecraft:custom_data~{ripperdoc_id:"berserk"}] run scoreboard players set @s rd_has_b 1
execute if score @s rd_has_b matches 1.. if entity @s[tag=rd_berserk] run function ripperdoc:visual/berserk_active
execute if score @s rd_has_b matches 1.. unless entity @s[tag=rd_berserk] run function ripperdoc:visual/berserk_inactive

execute store result score @s rd_has_a run clear @s minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] 0
execute if score @s rd_has_a matches 0 if items entity @s player.cursor minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run scoreboard players set @s rd_has_a 1
execute if score @s rd_has_a matches 0 if items entity @s weapon.offhand minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run scoreboard players set @s rd_has_a 1
execute if score @s rd_has_a matches 0 if items entity @s player.crafting.* minecraft:nautilus_shell[minecraft:custom_data~{ripperdoc_id:"aquatic"}] run scoreboard players set @s rd_has_a 1
execute if score @s rd_has_a matches 1.. if entity @s[tag=rd_aqua] run function ripperdoc:visual/aquatic_active
execute if score @s rd_has_a matches 1.. unless entity @s[tag=rd_aqua] run function ripperdoc:visual/aquatic_inactive
