tag @s add rd_moontech
attribute @s minecraft:jump_strength modifier remove ripperdoc:moontech_jump
attribute @s minecraft:jump_strength modifier add ripperdoc:moontech_jump 0.265 add_value
attribute @s minecraft:fall_damage_multiplier modifier remove ripperdoc:moontech_fall
scoreboard players set @s rd_air 0
scoreboard players set @s rd_jused 0
scoreboard players set @s rd_impulse 0
scoreboard players operation @s rd_jump_prev = @s rd_jumpstat
# Safety: an interrupted old impulse enchant must never remain on the boots.
item modify entity @s armor.feet ripperdoc:moontech_remove_impulse
scoreboard players set @s rd_moon_ground 0
scoreboard players set @s rd_moon_age 0
