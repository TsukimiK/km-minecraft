scoreboard players set @s rd_impulse 0
item modify entity @s armor.feet ripperdoc:moontech_remove_impulse
