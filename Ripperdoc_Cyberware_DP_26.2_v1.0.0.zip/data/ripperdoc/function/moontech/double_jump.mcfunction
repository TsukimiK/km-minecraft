# View-independent compensated second jump.
# 1) read current vertical velocity to cancel fall speed
# 2) choose local axis from pitch
# 3) compensate that axis projection so world-Y impulse stays nearly constant
scoreboard players set @s rd_jused 1
scoreboard players set @s rd_impulse 1
execute store result score @s rd_vy run data get entity @s Motion[1] 1000
execute if entity @s[x_rotation=-90..-85] run function ripperdoc:moontech/pitch/p01
execute if entity @s[x_rotation=-85..-80] run function ripperdoc:moontech/pitch/p02
execute if entity @s[x_rotation=-80..-75] run function ripperdoc:moontech/pitch/p03
execute if entity @s[x_rotation=-75..-70] run function ripperdoc:moontech/pitch/p04
execute if entity @s[x_rotation=-70..-65] run function ripperdoc:moontech/pitch/p05
execute if entity @s[x_rotation=-65..-60] run function ripperdoc:moontech/pitch/p06
execute if entity @s[x_rotation=-60..-55] run function ripperdoc:moontech/pitch/p07
execute if entity @s[x_rotation=-55..-50] run function ripperdoc:moontech/pitch/p08
execute if entity @s[x_rotation=-50..-45] run function ripperdoc:moontech/pitch/p09
execute if entity @s[x_rotation=-45..-40] run function ripperdoc:moontech/pitch/p10
execute if entity @s[x_rotation=-40..-35] run function ripperdoc:moontech/pitch/p11
execute if entity @s[x_rotation=-35..-30] run function ripperdoc:moontech/pitch/p12
execute if entity @s[x_rotation=-30..-25] run function ripperdoc:moontech/pitch/p13
execute if entity @s[x_rotation=-25..-20] run function ripperdoc:moontech/pitch/p14
execute if entity @s[x_rotation=-20..-15] run function ripperdoc:moontech/pitch/p15
execute if entity @s[x_rotation=-15..-10] run function ripperdoc:moontech/pitch/p16
execute if entity @s[x_rotation=-10..-5] run function ripperdoc:moontech/pitch/p17
execute if entity @s[x_rotation=-5..0] run function ripperdoc:moontech/pitch/p18
execute if entity @s[x_rotation=0..5] run function ripperdoc:moontech/pitch/p19
execute if entity @s[x_rotation=5..10] run function ripperdoc:moontech/pitch/p20
execute if entity @s[x_rotation=10..15] run function ripperdoc:moontech/pitch/p21
execute if entity @s[x_rotation=15..20] run function ripperdoc:moontech/pitch/p22
execute if entity @s[x_rotation=20..25] run function ripperdoc:moontech/pitch/p23
execute if entity @s[x_rotation=25..30] run function ripperdoc:moontech/pitch/p24
execute if entity @s[x_rotation=30..35] run function ripperdoc:moontech/pitch/p25
execute if entity @s[x_rotation=35..40] run function ripperdoc:moontech/pitch/p26
execute if entity @s[x_rotation=40..45] run function ripperdoc:moontech/pitch/p27
execute if entity @s[x_rotation=45..50] run function ripperdoc:moontech/pitch/p28
execute if entity @s[x_rotation=50..55] run function ripperdoc:moontech/pitch/p29
execute if entity @s[x_rotation=55..60] run function ripperdoc:moontech/pitch/p30
execute if entity @s[x_rotation=60..65] run function ripperdoc:moontech/pitch/p31
execute if entity @s[x_rotation=65..70] run function ripperdoc:moontech/pitch/p32
execute if entity @s[x_rotation=70..75] run function ripperdoc:moontech/pitch/p33
execute if entity @s[x_rotation=75..80] run function ripperdoc:moontech/pitch/p34
execute if entity @s[x_rotation=80..85] run function ripperdoc:moontech/pitch/p35
execute if entity @s[x_rotation=85..90] run function ripperdoc:moontech/pitch/p36
