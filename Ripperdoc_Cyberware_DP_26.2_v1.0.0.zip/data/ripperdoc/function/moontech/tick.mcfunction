# Track air time for second-jump debounce.
execute if entity @s[nbt={OnGround:1b}] run scoreboard players set @s rd_air 0
execute unless entity @s[nbt={OnGround:1b}] run scoreboard players add @s rd_air 1

# A real ground jump increments minecraft.custom:minecraft.jump. Walking off a cliff does not.
execute if score @s rd_jumpstat > @s rd_jump_prev unless entity @s[nbt={FallFlying:1b}] unless data entity @s RootVehicle run function ripperdoc:moontech/fall_start
scoreboard players operation @s rd_jump_prev = @s rd_jumpstat

# Keep fall protection through the actual landing-damage tick.
# A single transient OnGround tick (block edge / step / AQUATIC platform transition) is not enough to end the session.
execute if entity @s[tag=rd_moon_fall] run scoreboard players add @s rd_moon_age 1
execute if entity @s[tag=rd_moon_fall,nbt={OnGround:1b}] run scoreboard players add @s rd_moon_ground 1
execute if entity @s[tag=rd_moon_fall] unless entity @s[nbt={OnGround:1b}] run scoreboard players set @s rd_moon_ground 0
execute if entity @s[tag=rd_moon_fall,scores={rd_moon_ground=3..}] run function ripperdoc:moontech/landed

# Session escape hatches: no protection leaks into unrelated movement states.
execute if entity @s[tag=rd_moon_fall] if block ~ ~ ~ minecraft:water run function ripperdoc:moontech/fall_end
execute if entity @s[tag=rd_moon_fall] if block ~ ~ ~ minecraft:lava run function ripperdoc:moontech/fall_end
execute if entity @s[tag=rd_moon_fall] if block ~ ~ ~ #minecraft:climbable run function ripperdoc:moontech/fall_end
execute if entity @s[tag=rd_moon_fall] if data entity @s RootVehicle run function ripperdoc:moontech/fall_end
execute if entity @s[tag=rd_moon_fall,nbt={FallFlying:1b}] run function ripperdoc:moontech/fall_end
# Backstop only; normal MOONTECH jumps land long before 60 seconds.
execute if entity @s[tag=rd_moon_fall,scores={rd_moon_age=1200..}] run function ripperdoc:moontech/fall_end

# SPACE release -> SPACE press while airborne. A valid second jump requires a real first-jump session.
execute if entity @s[tag=rd_moon_fall] if score @s rd_air matches 2.. if score @s rd_jused matches 0 if predicate ripperdoc:is_jumping unless entity @s[tag=rd_jump_held] unless entity @s[nbt={FallFlying:1b}] unless data entity @s RootVehicle unless block ~ ~ ~ minecraft:water unless block ~ ~ ~ minecraft:lava unless block ~ ~ ~ #minecraft:climbable run function ripperdoc:moontech/double_jump
