attribute @s minecraft:jump_strength modifier remove ripperdoc:moontech_jump
attribute @s minecraft:fall_damage_multiplier modifier remove ripperdoc:moontech_fall
scoreboard players set @s rd_air 0
scoreboard players set @s rd_jused 0
scoreboard players set @s rd_impulse 0
scoreboard players operation @s rd_jump_prev = @s rd_jumpstat
execute if items entity @s armor.feet * run item modify entity @s armor.feet ripperdoc:moontech_remove_impulse
tag @s remove rd_moontech
tag @s remove rd_moon_fall
tag @s remove rd_jump_held
scoreboard players set @s rd_moon_ground 0
scoreboard players set @s rd_moon_age 0
