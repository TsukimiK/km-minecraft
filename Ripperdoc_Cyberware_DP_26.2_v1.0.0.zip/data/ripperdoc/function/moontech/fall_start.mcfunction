# Start protection only from a real MOONTECH jump.
tag @s add rd_moon_fall
scoreboard players set @s rd_moon_ground 0
scoreboard players set @s rd_moon_age 0
scoreboard players set @s rd_jused 0
attribute @s minecraft:fall_damage_multiplier modifier remove ripperdoc:moontech_fall
attribute @s minecraft:fall_damage_multiplier modifier add ripperdoc:moontech_fall -1 add_value
