attribute @s minecraft:fall_damage_multiplier modifier remove ripperdoc:moontech_fall
tag @s remove rd_moon_fall
scoreboard players set @s rd_moon_ground 0
scoreboard players set @s rd_moon_age 0
