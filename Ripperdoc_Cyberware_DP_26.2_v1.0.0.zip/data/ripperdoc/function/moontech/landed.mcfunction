# Three consecutive grounded ticks confirm a real landing.
function ripperdoc:moontech/fall_end
scoreboard players set @s rd_air 0
scoreboard players set @s rd_jused 0
