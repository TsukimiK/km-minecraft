attribute @s minecraft:movement_speed modifier remove ripperdoc:zandevistan
attribute @s minecraft:attack_damage modifier remove ripperdoc:berserk_damage
attribute @s minecraft:block_break_speed modifier remove ripperdoc:berserk_mining
attribute @s minecraft:jump_strength modifier remove ripperdoc:moontech_jump
attribute @s minecraft:fall_damage_multiplier modifier remove ripperdoc:moontech_fall
execute if items entity @s armor.feet minecraft:netherite_boots run item modify entity @s armor.feet ripperdoc:moontech_remove_impulse
scoreboard players set @s rd_zande 0
scoreboard players set @s rd_berserk 0
scoreboard players set @s rd_aqua 0
scoreboard players set @s rd_air 0
scoreboard players set @s rd_jused 0
scoreboard players set @s rd_impulse 0
scoreboard players set @s rd_vy 0
scoreboard players set @s rd_death 0
scoreboard players set @s rd_pid 0
scoreboard players set @s rd_owner 0
scoreboard players set @s rd_clock 0
scoreboard players set @s rd_y 0
scoreboard players set @s rd_yprev 0
scoreboard players set @s rd_init 0
scoreboard players set @s rd_has_z 0
scoreboard players set @s rd_has_b 0
scoreboard players set @s rd_has_a 0
scoreboard players set @s rd_miss_z 0
scoreboard players set @s rd_miss_b 0
scoreboard players set @s rd_miss_a 0
scoreboard players set @s rd_seen_z 0
scoreboard players set @s rd_seen_b 0
scoreboard players set @s rd_seen_a 0
scoreboard players set @s rd_hold_z 0
scoreboard players set @s rd_hold_b 0
scoreboard players set @s rd_hold_a 0
scoreboard players set @s rd_jump_prev 0
scoreboard players set @s rd_moon_ground 0
scoreboard players set @s rd_moon_age 0
scoreboard players operation @s rd_jump_prev = @s rd_jumpstat
tag @s remove rd_zande
tag @s remove rd_berserk
tag @s remove rd_aqua
tag @s remove rd_moontech
tag @s remove rd_moon_fall
tag @s remove rd_jump_held
tag @s remove rd_aqsurf
tag @s remove rd_aq_onwater
tag @s remove rd_aq_landing
tag @s remove rd_toggle_off
tag @s remove rd_use_offhand
