km-minecraft 26.2 - Production Resource Pack

Active custom visuals:
- Vegeter BOX / cigarette
- Daikon / cooked daikon / seeds
- Asahatamon / cooked Asahatamon
- Normal + rare crop stages
- Daikon sword / pickaxe / axe / shovel

Backpack/shulker experiment is not included.
