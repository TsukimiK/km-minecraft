km-minecraft 26.2 - Production Resource Pack

Active visuals:
- Vegeter BOX / cigarette
- Daikon / cooked Daikon / seeds
- Asahatamon / cooked Asahatamon
- Normal / rare crop growth stages
- Daikon sword / pickaxe / axe / shovel
- Daikon armor set
- Daikon shield

Final visual implementation:
- Daikon armor item models inherit vanilla iron armor item models.
- Daikon armor uses the approved original four Daikon designs.
- Equipped armor uses the Daikon equipment asset.
- Daikon shield uses Minecraft's native shield special renderer.
- Custom experimental shield geometry / handle models are not included.
- Backpack / shulker experiments are not included.
